
package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners (GenerateReport.class)
public class Humanitec {
	
	@Test
	public static void  main (String[]args) throws InterruptedException {

	    Assert.assertTrue(true);
	    
	    //System.setProperty("webdriver.chromedriver","C:/Users/abdalfatah/Desktop/Selenuim/chromedriver_win32/chromedriver.exe");
	    //WebDriver driver = new ChromeDriver();
		
	    System.setProperty("webdriver.gecko.driver","C:/Users/abdalfatah/Desktop/Selenuim/geckodriver-v0.20.0-win64/geckodriver.exe");
		//WebDriver driver1 = new FirefoxDriver();
		 
		FirefoxProfile profile = new FirefoxProfile();
		profile.setPreference("permissions.default.desktop-notification", 1);
		DesiredCapabilities capabilities=DesiredCapabilities.firefox();
		capabilities.setCapability(FirefoxDriver.PROFILE, profile);
		WebDriver driver1 = new FirefoxDriver(capabilities);
		driver1.get("https://www.ultimateqa.com/filling-out-forms/"); 
		
	    Thread.sleep(3000);

	    driver1.findElement(By.xpath("//*[@id=\"et_pb_contact_name_1\"]")).sendKeys(new String[]{"Abed al fatah"});
	  
	    driver1.findElement(By.xpath("//*[@id=\"et_pb_contact_message_1\"]")).sendKeys(new String[]{"HOpe this message finds you in a good health and spirit"});
	  
	    driver1.findElement(By.cssSelector("#et_pb_contact_form_0 > div.et_pb_contact > form > div > button")).click();
				
	}
}





