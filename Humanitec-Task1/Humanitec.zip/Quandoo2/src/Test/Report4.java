package Test;


import org.testng.annotations.Test;

public class Report4  {

	
	@Test
	public void Humanitec(){
	
		System.out.println ("test 1 is successfull");
	
}
	
}




